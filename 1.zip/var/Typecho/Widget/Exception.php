<?php

namespace Typecho\Widget;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

use Typecho\Exception as TypechoException;

/**
 * 组件异常类
 *
 * @package Widget
 */
class Exception extends TypechoException
{
}
